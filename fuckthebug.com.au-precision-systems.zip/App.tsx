
import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Dashboard from './components/Dashboard';
import ValueProposition from './components/ValueProposition';
import Contact from './components/Contact';
import Footer from './components/Footer';
import BugBackground from './components/BugBackground';

const App: React.FC = () => {
  return (
    <div className="min-h-screen font-inter selection:bg-neonCyan selection:text-black relative bg-darkBg">
      <BugBackground />
      <Navbar />
      <main>
        <Hero />
        
        <div className="max-w-7xl mx-auto px-6">
           <div className="glowing-separator opacity-40"></div>
        </div>

        <ValueProposition />

        <div className="max-w-7xl mx-auto px-6">
           <div className="glowing-separator opacity-40"></div>
        </div>

        <Dashboard />

        <div className="max-w-7xl mx-auto px-6">
           <div className="glowing-separator opacity-40"></div>
        </div>

        <Contact />
      </main>
      <Footer />
    </div>
  );
};

export default App;
